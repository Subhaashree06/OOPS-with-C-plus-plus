const sections = {
  dashboard: "dashboard",
  quality: "qualitySection",
  storage: "storageSection",
  distribution: "distributionSection"
};

const $ = id => document.getElementById(id);

// Navigation
function showSection(sectionName, clickedButton) {
  const targetId = sections[sectionName];
  const target = document.getElementById(targetId);

  if (!target) {
    console.error("Section not found:", targetId);
    return;
  }

  document.querySelectorAll(".nav").forEach(btn => btn.classList.remove("active"));

  const button = clickedButton ||
    document.querySelector(`.nav[data-section="${sectionName}"]`);

  if (button) button.classList.add("active");

  document.querySelectorAll(".section").forEach(section => {
    section.classList.remove("active");
  });

  target.classList.add("active");

  const title = button ? button.querySelector("span") : null;
  if (title) $("pageTitle").textContent = title.textContent;

  window.scrollTo({ top: 0, behavior: "smooth" });
}

// Delegated fallback ensures the sidebar remains clickable even after DOM updates.
document.addEventListener("click", event => {
  const btn = event.target.closest(".nav");
  if (!btn) return;
  event.preventDefault();
  showSection(btn.dataset.section, btn);
});


function clock() {
  $("clock").textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
}
setInterval(clock, 1000);
clock();

async function api(path) {
  const response = await fetch(path);
  if (!response.ok) throw new Error("Backend request failed");
  return response.json();
}

async function loadDashboard() {
  try {
    const d = await api("/api/dashboard");
    $("quality").textContent = d.quality;
    $("storage").textContent = Math.round(d.storage / d.capacity * 100);
    $("storageLitres").textContent = Number(d.storage).toLocaleString();
    $("distributed").textContent = Number(d.distributed).toLocaleString() + " L";
    $("ph").textContent = d.ph;
    $("temp").textContent = d.temperature;
    $("turbidity").textContent = d.turbidity;
    $("tds").textContent = d.tds;
    $("tankFill").style.height = (d.storage / d.capacity * 100) + "%";
  } catch (e) {
    console.log("Backend not running");
  }
}

async function checkQuality() {
  try {
    const ph = $("qph").value;
    const temp = $("qtemp").value;
    const turbidity = $("qturb").value;
    const tds = $("qtds").value;
    const r = await api(`/api/quality?ph=${encodeURIComponent(ph)}&temp=${encodeURIComponent(temp)}&turbidity=${encodeURIComponent(turbidity)}&tds=${encodeURIComponent(tds)}`);
    const el = $("qualityResult");
    el.textContent = `${r.status}: ${r.message}`;
    el.className = `result ${r.status.toLowerCase()}`;
  } catch (e) {
    showBackendError("qualityResult");
  }
}

async function checkStorage() {
  try {
    const capacity = Number($("scapacity").value);
    const level = Number($("slevel").value);
    const alert = Number($("salert").value);

    if (!capacity || capacity <= 0 || level < 0 || alert < 0 || alert > 100) {
      const el = $("storageResult");
      el.textContent = "ERROR: Enter valid capacity, water level and alert percentage.";
      el.className = "result error";
      return;
    }

    const r = await api(`/api/storage?capacity=${capacity}&level=${level}&alert=${alert}`);
    const percent = Number(r.percent);

    $("storageBig").textContent = Number(r.level).toLocaleString() + " L";
    $("capacityBig").textContent = Number(r.capacity).toLocaleString() + " L";
    $("storagePercent").textContent = Math.round(percent) + "%";
    $("availableCapacity").textContent = Number(r.available).toLocaleString() + " L";
    $("distributedStorage").textContent = "5,250 L";
    $("storageProgress").style.width = Math.max(0, Math.min(100, percent)) + "%";

    const pill = $("storageStatusPill");
    pill.textContent = r.status;
    pill.className = `status-pill ${r.status.toLowerCase()}`;

    const result = $("storageResult");
    result.textContent = r.message;
    result.className = `result ${r.status.toLowerCase()}`;

    $("availabilityFeature").textContent = percent > 0 ? "AVAILABLE" : "EMPTY";
    $("overflowFeature").textContent = percent >= 100 ? "LIMIT REACHED" : "ACTIVE";
    $("lowFeature").textContent = percent <= alert ? "ALERT ACTIVE" : "ACTIVE";
  } catch (e) {
    showBackendError("storageResult");
  }
}

function statusClass(status) {
  if (status === "APPROVED") return "approved";
  if (status === "LEAK WARNING") return "warning";
  if (status === "LOW FLOW") return "lowflow";
  return "warning";
}

function addDistributionRow(r) {
  const row = document.createElement("tr");
  row.innerHTML = `
    <td>${escapeHtml(r.area)}</td>
    <td>${Number(r.demand).toLocaleString()} L</td>
    <td>${Number(r.quantity).toLocaleString()} L</td>
    <td>${Number(r.flow).toLocaleString()} L/min</td>
    <td>${Number(r.expected).toLocaleString()} L/min</td>
    <td><span class="table-status ${statusClass(r.status)}">${escapeHtml(r.status)}</span></td>`;
  $("distributionTable").prepend(row);
}

async function checkDistribution() {
  try {
    const area = $("darea").value;
    const demand = Number($("ddemand").value);
    const quantity = Number($("dquantity").value);
    const flow = Number($("dflow").value);
    const expected = Number($("dexpected").value);

    if (demand < 0 || quantity < 0 || flow < 0 || expected < 0) {
      const el = $("distributionResult");
      el.textContent = "ERROR: Enter non-negative distribution values.";
      el.className = "result error";
      return;
    }

    const r = await api(`/api/distribution?area=${encodeURIComponent(area)}&demand=${demand}&quantity=${quantity}&flow=${flow}&expected=${expected}`);
    const el = $("distributionResult");
    el.textContent = `${r.status}: ${r.message}`;
    el.className = `result ${statusClass(r.status)}`;

    $("leakFeature").textContent = r.status === "LEAK WARNING" ? "ALERT" : "ACTIVE";
    $("lowFlowFeature").textContent = r.status === "LOW FLOW" ? "ALERT" : "ACTIVE";

    addDistributionRow(r);
  } catch (e) {
    showBackendError("distributionResult");
  }
}

function showBackendError(id) {
  const el = $(id);
  el.textContent = "ERROR: Unable to connect to C++ backend.";
  el.className = "result error";
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;"
  }[ch]));
}

loadDashboard();
