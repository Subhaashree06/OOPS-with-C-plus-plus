# Smart Water Management - C++ Web Project

This version combines all three project modules:

1. Water Quality Monitoring - original module retained.
2. Water Storage and Monitoring - dynamic capacity, current level and low-level alert percentage.
3. Water Distribution Management - demand, quantity, actual flow and expected flow with leak/low-flow/approved logic.

## Module 2 logic
- Current level percentage = current water level / tank capacity * 100.
- If percentage <= user-entered low-level alert, LOW LEVEL warning is shown.
- If percentage >= 90%, HIGH STORAGE warning is shown.
- Otherwise NORMAL is shown.
- The displayed percentage, litres and available capacity update from the values entered by the user.

## Module 3 logic
- Actual pipeline flow > expected flow: LEAK WARNING.
- Actual pipeline flow < expected flow: LOW FLOW warning.
- Actual pipeline flow = expected flow: APPROVED.
- If distribution quantity exceeds demand, EXCESS SUPPLY is reported.

## Run with MSYS2 UCRT64
Open MSYS2 UCRT64 and run:

```bash
cd /c/Users/subha/Downloads/SmartWater_Cpp_Web_Simple/SmartWater_Cpp_Web/backend
g++ main.cpp -o main.exe -lws2_32
./main.exe
```

Keep the MSYS2 window open and open:

http://127.0.0.1:8081
