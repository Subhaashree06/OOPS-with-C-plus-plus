#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include <algorithm>
#include <iomanip>
#include <cmath>

#pragma comment(lib, "ws2_32.lib")

std::string readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file) return "";
    std::ostringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

std::string contentType(const std::string& path) {
    if (path.size() >= 5 && path.substr(path.size()-5) == ".html") return "text/html; charset=utf-8";
    if (path.size() >= 4 && path.substr(path.size()-4) == ".css")  return "text/css; charset=utf-8";
    if (path.size() >= 3 && path.substr(path.size()-3) == ".js")   return "application/javascript; charset=utf-8";
    if (path.size() >= 5 && path.substr(path.size()-5) == ".json") return "application/json; charset=utf-8";
    return "text/plain; charset=utf-8";
}

std::string jsonDashboard() {
    return R"({
        "quality":"SAFE",
        "ph":7.2,
        "temperature":28,
        "turbidity":3.5,
        "tds":250,
        "storage":6500,
        "capacity":10000,
        "distributed":5250
    })";
}

std::string jsonQuality(double ph, double temp, double turbidity, double tds) {
    bool safe = ph >= 6.5 && ph <= 8.5 &&
                temp >= 10 && temp <= 35 &&
                turbidity <= 5 && turbidity >= 0 &&
                tds <= 500 && tds >= 0;

    return std::string("{\"status\":\"") + (safe ? "SAFE" : "UNSAFE") +
           "\",\"message\":\"" +
           (safe ? "Water quality is within safe limits." :
                   "One or more parameters exceed safe limits.") + "\"}";
}

std::string jsonStorage(double capacity, double level, double alertPercent) {
    if (capacity <= 0) capacity = 10000;
    level = std::max(0.0, std::min(level, capacity));
    alertPercent = std::max(0.0, std::min(alertPercent, 100.0));

    double percent = (level / capacity) * 100.0;
    std::string status;
    std::string message;

    if (percent <= alertPercent) {
        status = "LOW";
        message = "LOW LEVEL: Water level is " + std::to_string((int)std::round(percent)) +
                  "%, below the " + std::to_string((int)std::round(alertPercent)) + "% alert threshold.";
    } else if (percent >= 90.0) {
        status = "HIGH";
        message = "HIGH STORAGE: Tank is " + std::to_string((int)std::round(percent)) + "% full.";
    } else {
        status = "NORMAL";
        message = "NORMAL: Storage level is " + std::to_string((int)std::round(percent)) + "%.";
    }

    std::ostringstream out;
    out << std::fixed << std::setprecision(1);
    out << "{\"status\":\"" << status
        << "\",\"message\":\"" << message
        << "\",\"capacity\":" << capacity
        << ",\"level\":" << level
        << ",\"percent\":" << percent
        << ",\"available\":" << (capacity - level)
        << ",\"distributed\":5250}";
    return out.str();
}

std::string jsonDistribution(const std::string& area, double demand, double quantity,
                             double actualFlow, double expectedFlow) {
    std::string status;
    std::string message;

    // Requested logic:
    // actual flow > expected flow  -> leak warning
    // actual flow < expected flow  -> low-flow warning
    // actual flow == expected flow -> approved
    const double tolerance = 0.0001;
    if (actualFlow > expectedFlow + tolerance) {
        status = "LEAK WARNING";
        message = "WARNING: Possible leakage detected in " + area +
                  ". Actual flow is greater than expected flow.";
    } else if (actualFlow + tolerance < expectedFlow) {
        status = "LOW FLOW";
        message = "LOW FLOW: Supply flow to " + area +
                  " is below the expected flow.";
    } else {
        status = "APPROVED";
        message = "APPROVED: Flow to " + area + " matches the expected flow.";
    }

    // A distribution quantity greater than demand is also flagged as an input warning.
    if (quantity > demand + tolerance) {
        status = "EXCESS SUPPLY";
        message = "WARNING: Distribution quantity exceeds the stated demand for " + area + ".";
    }

    std::ostringstream out;
    out << std::fixed << std::setprecision(1);
    out << "{\"status\":\"" << status
        << "\",\"message\":\"" << message
        << "\",\"area\":\"" << area
        << "\",\"demand\":" << demand
        << ",\"quantity\":" << quantity
        << ",\"flow\":" << actualFlow
        << ",\"expected\":" << expectedFlow << "}";
    return out.str();
}

void sendResponse(SOCKET client, const std::string& body,
                  const std::string& type = "text/html; charset=utf-8",
                  int status = 200) {
    std::string statusText = status == 200 ? "OK" : "Not Found";
    std::ostringstream response;
    response << "HTTP/1.1 " << status << " " << statusText << "\r\n";
    response << "Content-Type: " << type << "\r\n";
    response << "Access-Control-Allow-Origin: *\r\n";
    response << "Content-Length: " << body.size() << "\r\n";
    response << "Connection: close\r\n\r\n";
    response << body;
    std::string out = response.str();
    send(client, out.c_str(), static_cast<int>(out.size()), 0);
}

std::string urlDecode(std::string value) {
    std::string result;
    for (size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '%' && i + 2 < value.size()) {
            try {
                int code = std::stoi(value.substr(i + 1, 2), nullptr, 16);
                result += static_cast<char>(code);
                i += 2;
            } catch (...) {
                result += value[i];
            }
        } else if (value[i] == '+') {
            result += ' ';
        } else {
            result += value[i];
        }
    }
    return result;
}

std::string getParam(const std::string& path, const std::string& key, const std::string& fallback) {
    size_t q = path.find('?');
    if (q == std::string::npos) return fallback;

    std::string query = path.substr(q + 1);
    std::istringstream parts(query);
    std::string part;
    while (std::getline(parts, part, '&')) {
        size_t eq = part.find('=');
        if (eq == std::string::npos) continue;
        std::string k = urlDecode(part.substr(0, eq));
        if (k == key) return urlDecode(part.substr(eq + 1));
    }
    return fallback;
}

double getDoubleParam(const std::string& path, const std::string& key, double fallback) {
    try {
        return std::stod(getParam(path, key, std::to_string(fallback)));
    } catch (...) {
        return fallback;
    }
}

int main() {
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) {
        std::cerr << "WSAStartup failed.\n";
        return 1;
    }

    SOCKET server = socket(AF_INET, SOCK_STREAM, 0);
    if (server == INVALID_SOCKET) {
        std::cerr << "Could not create socket.\n";
        WSACleanup();
        return 1;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    addr.sin_port = htons(8081);

    if (bind(server, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) == SOCKET_ERROR ||
        listen(server, 10) == SOCKET_ERROR) {
        std::cerr << "Could not start server on port 8081. Make sure port 8081 is free.\n";
        closesocket(server);
        WSACleanup();
        return 1;
    }

    std::cout << "Smart Water C++ server running at http://127.0.0.1:8081\n";
    std::cout << "Keep this window open while using the dashboard.\n";

    while (true) {
        SOCKET client = accept(server, nullptr, nullptr);
        if (client == INVALID_SOCKET) continue;

        char buffer[8192] = {};
        int received = recv(client, buffer, sizeof(buffer)-1, 0);
        if (received <= 0) {
            closesocket(client);
            continue;
        }

        std::string request(buffer, received);
        std::istringstream req(request);
        std::string method, path, version;
        req >> method >> path >> version;

        if (path == "/api/dashboard") {
            sendResponse(client, jsonDashboard(), "application/json; charset=utf-8");
        } else if (path.rfind("/api/quality?", 0) == 0) {
            sendResponse(client, jsonQuality(
                getDoubleParam(path, "ph", 7.2),
                getDoubleParam(path, "temp", 28),
                getDoubleParam(path, "turbidity", 3.5),
                getDoubleParam(path, "tds", 250)
            ), "application/json; charset=utf-8");
        } else if (path.rfind("/api/storage?", 0) == 0) {
            sendResponse(client, jsonStorage(
                getDoubleParam(path, "capacity", 10000),
                getDoubleParam(path, "level", 6500),
                getDoubleParam(path, "alert", 20)
            ), "application/json; charset=utf-8");
        } else if (path.rfind("/api/distribution?", 0) == 0) {
            sendResponse(client, jsonDistribution(
                getParam(path, "area", "Residential Area"),
                getDoubleParam(path, "demand", 2000),
                getDoubleParam(path, "quantity", 2000),
                getDoubleParam(path, "flow", 100),
                getDoubleParam(path, "expected", 100)
            ), "application/json; charset=utf-8");
        } else {
            std::string cleanPath = path;
            size_t q = cleanPath.find('?');
            if (q != std::string::npos) cleanPath = cleanPath.substr(0, q);
            if (cleanPath == "/") cleanPath = "/index.html";

            if (cleanPath.find("..") != std::string::npos) {
                sendResponse(client, "Not Found", "text/plain; charset=utf-8", 404);
            } else {
                std::string filePath = "../frontend" + cleanPath;
                std::string body = readFile(filePath);
                if (body.empty()) sendResponse(client, "Not Found", "text/plain; charset=utf-8", 404);
                else sendResponse(client, body, contentType(filePath));
            }
        }

        closesocket(client);
    }

    closesocket(server);
    WSACleanup();
    return 0;
}
